// uthread3.c

#include "types.h"
#include "stat.h"
#include "user.h"

/* Possible states of a thread; */
#define FREE        0x0
#define RUNNING     0x1
#define RUNNABLE    0x2
#define WAIT        0x3

#define STACK_SIZE  8192
#define MAX_THREAD  10

typedef struct thread thread_t, *thread_p;

struct thread {
  int  tid;    /* thread id */
  int  sp;     /* saved stack pointer */
  char stack[STACK_SIZE];       /* the thread's stack */
  int  state;  /* FREE, RUNNING, RUNNABLE, WAIT */
};

/* Thread table and global pointers */
static thread_t all_thread[MAX_THREAD];
thread_p  current_thread;
thread_p  next_thread;

/* thread_switch is implemented in assembly */
extern void thread_switch(void);

/* -------------------------------------
   thread_schedule: Choose the next RUNNABLE thread 
   and switch context if needed
-------------------------------------- */
static void 
thread_schedule(void)
{
  thread_p t;

  /* Find another runnable thread. */
  next_thread = 0;
  for (t = all_thread; t < all_thread + MAX_THREAD; t++) {
    if (t->state == RUNNABLE && t != current_thread) {
      next_thread = t;
      break;
    }
  }

  /* If we found no other RUNNABLE thread 
     but the current thread is still RUNNABLE, run it again. */
  if (t >= all_thread + MAX_THREAD && current_thread->state == RUNNABLE) {
    next_thread = current_thread;
  }

  if (next_thread == 0) {
    /* No runnable threads at all */
    printf(2, "thread_schedule: no runnable threads\n");
    exit();
  }

  /* If we actually found a different thread to run, switch. */
  if (current_thread != next_thread) {
    next_thread->state = RUNNING;
    current_thread->state = RUNNABLE;
    thread_switch();
  } else {
    next_thread = 0;
  }
}

/* -------------------------------------
   thread_init: Initialize thread system 
   main thread is thread 0
-------------------------------------- */
void 
thread_init(void)
{
  printf(1, "thread_init intro");
  /* Register the user-level scheduler with the kernel. */
  uthread_init((int)thread_schedule);

  /* Make thread 0 the main thread. */
  current_thread = &all_thread[0];
  current_thread->state = RUNNING;
  current_thread->tid   = 0;
}

/* -------------------------------------
   thread_create: 
   1) Find a FREE slot
   2) Allocate stack and push return address
   3) state=RUNNABLE
-------------------------------------- */
int
thread_create(void (*func)())
{
  thread_p t;
  static int next_tid = 1;  // simple global TID counter
  printf(1, "thread_create intro\n");
  for (t = all_thread; t < all_thread + MAX_THREAD; t++) {
    if (t->state == FREE) {
      // Found a free slot
      t->tid = next_tid++;
      t->sp  = (int)(t->stack + STACK_SIZE);  // top of stack
      t->sp -= 4;                             // space for return address
      *(int *)(t->sp) = (int)func;            // push return address
      t->sp -= 32;                            // space for registers
      t->state = RUNNABLE;
      return t->tid;
    }
    printf(1, "thread_create outtro\n");
  }
  // No FREE slot
  printf(2, "thread_create: no available slot\n");
  return -1;
}

/* -------------------------------------
   thread_suspend(tid):
   change the thread with given tid 
   from RUNNABLE/RUNNING to WAIT
-------------------------------------- */
static void 
thread_suspend(int tid)
{
  int i;
  printf(1, "thread_suspend intro\n");
  for(i = 0; i < MAX_THREAD; i++){
    if(all_thread[i].tid == tid && all_thread[i].state != FREE){
      // If it's currently RUNNING, we might want to yield immediately
      if(all_thread[i].state == RUNNING){
        all_thread[i].state = WAIT;
        if(&all_thread[i] == current_thread){
          // current thread is suspended -> switch out
          thread_schedule();
        }
      } else {
        // If RUNNABLE or WAIT, just set WAIT
        all_thread[i].state = WAIT;
      }
      break;
    }
  }
}

/* -------------------------------------
   thread_resume(tid):
   change the thread with given tid 
   from WAIT to RUNNABLE
-------------------------------------- */
static void 
thread_resume(int tid)
{
  int i;
  printf(1, "thread_resume intro\n");
  for(i = 0; i < MAX_THREAD; i++){
    if(all_thread[i].tid == tid && all_thread[i].state == WAIT){
      all_thread[i].state = RUNNABLE;
      break;
    }
  }
}
void
thread_yield(void)
{
  current_thread->state = RUNNABLE;
  thread_schedule();
}
/* Simple test thread */
void 
mythread(void)
{
  printf(1, "mythread_init intro\n");
  int i;
  printf(1, "my thread running tid=%x\n", current_thread->tid);
  for (i = 0; i < 100; i++) {
    printf(1, "my thread %x\n", current_thread->tid);
    thread_yield();
  }
  printf(1, "my thread (tid=%d): exit\n", current_thread->tid);
  current_thread->state = FREE;
  thread_schedule();
}



/* -------------------------------------
   main: demonstration
   1) create two threads
   2) suspend/resume them in some order
-------------------------------------- */
int 
main(int argc, char *argv[]) 
{
  int tid1, tid2;
  printf(1, "main intro\n");
  thread_init();
  printf(1, " thread_init check");
  thread_create(mythread);
  tid1 = thread_create(mythread);
  tid2 = thread_create(mythread);
  

  sleep(1); /* give them some time to run */

  thread_suspend(tid1);
  sleep(5);

  thread_suspend(tid2);
  // Now both are suspended
  
  thread_resume(tid1);
  sleep(5);

  thread_resume(tid2);
  sleep(100);

  exit();
}

