// uthread4.c

#include "types.h"
#include "stat.h"
#include "user.h"

#define FREE        0x0
#define RUNNING     0x1
#define RUNNABLE    0x2

#define STACK_SIZE  8192
#define MAX_THREAD  10

typedef struct thread thread_t, *thread_p;

struct thread {
  int sp;
  int tid;        /* thread id */
  int ptid;       /* parent thread id */
  char stack[STACK_SIZE];
  int state;
};

thread_t all_thread[MAX_THREAD];
thread_p current_thread;
thread_p next_thread;

extern void thread_switch(void);

void thread_yield(void);

static void thread_schedule(void)
{
  thread_p t;
  next_thread = 0;

  for(t = all_thread; t < all_thread + MAX_THREAD; t++){
    if(t->state == RUNNABLE && t != current_thread){
      next_thread = t;
      break;
    }
  }

  if(next_thread == 0)
    return;

  next_thread->state = RUNNING;
  current_thread->state = RUNNABLE;
  thread_switch();
}

void thread_yield(void)
{
  current_thread->state = RUNNABLE;
  thread_schedule();
}

void thread_init(void)
{
  current_thread = &all_thread[0];
  current_thread->state = RUNNING;
  current_thread->tid = 0;    // Set main thread tid to 0
  current_thread->ptid = 0;   // Main thread has no parent
  uthread_init((int)thread_schedule);
}

int thread_create(void (*func)())
{
  thread_p t;
  int tid;

  for(tid = 1; tid < MAX_THREAD; tid++){
    if(all_thread[tid].state == FREE)
      break;
  }

  if(tid == MAX_THREAD){
    printf(2, "thread_create: no available slot\n");
    return -1;
  }

  t = &all_thread[tid];
  t->sp = (int)(t->stack + STACK_SIZE);
  t->sp -= 4;
  *(int*)(t->sp) = (int)func;
  t->sp -= 32;
  t->state = RUNNABLE;
  t->tid = tid;                     // Set thread id
  t->ptid = current_thread->tid;    // Set parent thread id

  return tid;
}

void thread_join(int tid)
{
  // Check if tid is valid
  if(tid < 0 || tid >= MAX_THREAD){
    printf(2, "thread_join: invalid tid %d\n", tid);
    return;
  }
  
  // Wait until the thread with the specified tid is FREE (completed)
  while(all_thread[tid].state != FREE){
    thread_yield();
  }
}

static void child_thread(void)
{
  int i;
  for(i = 0; i < 10; i++){
    printf(1, "child_thread (tid=%d, ptid=%d): i=%d\n", 
           current_thread->tid, current_thread->ptid, i);
    thread_yield();
  }
  printf(1, "child_thread (tid=%d): exiting\n", current_thread->tid);
  current_thread->state = FREE;
  thread_schedule();
}

static void mythread(void)
{
  int i;
  int child_tids[3];
  
  printf(1, "mythread (tid=%d): starting\n", current_thread->tid);
  
  // Create three child threads
  for(i = 0; i < 3; i++){
    child_tids[i] = thread_create(child_thread);
    printf(1, "mythread: created child thread %d\n", child_tids[i]);
  }
  
  // Join each child thread
  for(i = 0; i < 3; i++){
    printf(1, "mythread: joining child %d\n", child_tids[i]);
    thread_join(child_tids[i]);
    printf(1, "mythread: child %d has finished\n", child_tids[i]);
  }
  
  printf(1, "mythread (tid=%d): exiting\n", current_thread->tid);
  current_thread->state = FREE;
  thread_schedule();
}

int main(int argc, char *argv[])
{
  int mythread_tid;

  thread_init();
  printf(1, "main: creating mythread\n");
  mythread_tid = thread_create(mythread);
  
  printf(1, "main: joining mythread (tid=%d)\n", mythread_tid);
  thread_join(mythread_tid);
  printf(1, "main: mythread finished\n");
  
  printf(1, "main: exiting\n");
  exit();
}


