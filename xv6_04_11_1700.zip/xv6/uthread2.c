// uthread2.c

#include "types.h"
#include "stat.h"
#include "user.h"

/* Possible states of a thread */
#define FREE        0x0
#define RUNNING     0x1
#define RUNNABLE    0x2

#define STACK_SIZE  8192
#define MAX_THREAD  4

void thread_yield(void);//mskhh

typedef struct thread thread_t, *thread_p;

struct thread {
  int sp;                 /* saved stack pointer */
  char stack[STACK_SIZE]; /* the thread's stack */
  int state;              /* FREE, RUNNING, RUNNABLE */
};

/* Global thread array and pointers.
   current_thread and next_thread must be visible to the assembly code. */
thread_t all_thread[MAX_THREAD];
thread_p current_thread;
thread_p next_thread;

extern void thread_switch(void);

/* thread_schedule: Find the next runnable thread and perform a context switch. */
static void thread_schedule(void)
{
    thread_p t;
    next_thread = 0;
    
    for(t = all_thread; t < all_thread + MAX_THREAD; t++){
        if(t->state == RUNNABLE && t != current_thread){
            next_thread = t;
            break;
        }
    }
    /* If no runnable thread found, simply return (join_all will detect completion) */
    if(next_thread == 0)
        return;
    
    /* Ensure the next thread is set to RUNNABLE */
    next_thread->state = RUNNABLE;
    thread_switch();
}

/* New function: Wait until all child threads finish execution.
   Assumes that thread slot 0 is the main thread and child threads are at indices 1..MAX_THREAD-1.
*/
void thread_join_all(void)
{
    int i;
    while(1){
        int all_done = 1;
        for(i = 1; i < MAX_THREAD; i++){
            if(all_thread[i].state != FREE){
                all_done = 0;
                break;
            }
        }
        if(all_done)
            break;
        thread_yield();  // Yield to allow other threads to run and finish.
    }
}

/* thread_init: Initialize the thread system.
   Main thread is thread 0.
*/
void thread_init(void)
{
    current_thread = &all_thread[0];
    current_thread->state = RUNNING;
    uthread_init((int)thread_schedule);
}

/* thread_create: Create a new thread that will run the given function. */
void thread_create(void (*func)())
{
    thread_p t;
    for(t = all_thread; t < all_thread + MAX_THREAD; t++){
        if(t->state == FREE)
            break;
    }
    if(t >= all_thread + MAX_THREAD){
        printf(2, "thread_create: no available thread slot\n");
        return;
    }
    t->sp = (int)(t->stack + STACK_SIZE);  // Set sp to the top of the stack.
    t->sp -= 4;                            // Make space for return address.
    *(int *)(t->sp) = (int)func;             // Push function address as return address.
    t->sp -= 32;                           // Reserve space for registers used by thread_switch.
    t->state = RUNNABLE;
}

/* thread_yield: Yield execution to the scheduler */
void thread_yield(void)
{
    current_thread->state = RUNNABLE;
    thread_schedule();
}

/* A sample child thread function */
static void child_thread(void)
{
    int i;
    printf(1, "child thread running\n");
    for(i = 0; i < 50; i++){
        printf(1, "child: 0x%x\n", (int)current_thread);
        thread_yield();
    }
    printf(1, "child thread: exit\n");
    current_thread->state = FREE;
    thread_schedule();
}

/* Main function:
   1. Initializes the thread system.
   2. Creates two child threads.
   3. Waits for all child threads to finish using thread_join_all.
*/
int main(int argc, char *argv[])
{
    thread_init();
    thread_create(child_thread);
    thread_create(child_thread);
    printf(1, "main thread: waiting for child threads to finish\n");
    thread_join_all();
    printf(1, "main thread: all child threads finished. Exiting.\n");
    exit();
}

