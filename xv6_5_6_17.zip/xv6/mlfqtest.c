#include "types.h"
#include "stat.h"
#include "user.h"
#include "pstat.h"

#define NCHILD 3
#define SNAPSHOT_CNT 20
#define SNAPSHOT_INTERVAL 10000000

void workload(int n) {
  int i, j = 0;
  for(i = 0; i < n; i++)
    j += i * j + 1;
}

int main(void) {
  struct pstat st;
  int pid[NCHILD];
  int i, snap, k;

  printf(1,"start mlfqtest\n");

  // MLFQ로 스케줄링 정책 변경
  if(setSchedPolicy(1) != 0) {
    printf(1, "setSchedPolicy failed\n");
    exit();
  }

  // 자식 프로세스 생성
  for(i = 0; i < NCHILD; i++) {
    pid[i] = fork();
    if(pid[i] == 0) {
      // 각자 다른 workload (큐 강등 유도)
      for(k=0; k<6; k++) {
        workload(30000000 * (i+1)); // i=0:8M, i=1:16M, i=2:24M 등
        sleep(10); // 일부러 잠깐씩 쉬어서 대기시간도 변화
      }
      exit();
    }
  }

  // 여러 번 getpinfo로 상태 변화 추적
  for(snap=0; snap<SNAPSHOT_CNT; snap++) {
    sleep(50); // 50 ticks마다 스냅샷
    if(getpinfo(&st) < 0){
      printf(1, "getpinfo failed\n");
      exit();
    }
    printf(1, "\n[Snapshot %d]\n", snap);
    printf(1, "PID\tInUse\tPriority\tState\tTicks(Q3 Q2 Q1 Q0)\tWait(Q3 Q2 Q1 Q0)\n");
    for(i = 0; i < NPROC; i++) {
      if(st.inuse[i]==0 && (st.pid[i]==pid[0]||st.pid[i]==pid[1]||st.pid[i]==pid[2])) {
        printf(1, "%d\t%d\t%d\t\t%d\t%d %d %d %d\t%d %d %d %d\n",
          st.pid[i], st.inuse[i], st.priority[i], st.state[i],
          st.ticks[i][3], st.ticks[i][2], st.ticks[i][1], st.ticks[i][0],
          st.wait_ticks[i][3], st.wait_ticks[i][2], st.wait_ticks[i][1], st.wait_ticks[i][0]);
      }
    }
  }

  // 모든 자식 종료 대기
  for(i = 0; i < NCHILD; i++){
    wait();
  }
  exit();
}

