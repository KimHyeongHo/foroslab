//mlfq3.c
#include "types.h"
#include "stat.h"
#include "user.h"
#include "pstat.h"
#define NCHILD 4
void workload(int n) {
  int i, j = 0;
  for(i = 0; i < n; i++)
    j += i * j + 1;
}

int main(void) {
  struct pstat st;
  int pid[NCHILD];
  int i, k,ii;

  if(setSchedPolicy(1) != 0) {
    printf(1, "setSchedPolicy failed\n");
    exit();
  }

  for(i = 0; i < NCHILD; i++) {
    pid[i] = fork();
    if(pid[i] == 0) {
      if(i == 0) {
        // Process 1 : yield() before 8 ticks (치팅)
        for(k = 0; k < 10; k++) {
          workload(400000); // 짧게 일하고
          sleep(1);
        }
      }
      else if(i == 1) {
        // Process 2: yield() before 16 ticks (치팅)
        for(k = 0; k < 10; k++) {
          workload(8000000); // 짧게 일하고
          sleep(1);
        }
      } 
      else if(i == 2)
      {
        // Process 3 : yield() before 32 ticks (치팅)
        for(k = 0; k < 10; k++) {
          workload(16000000); // 충분히 길게 일해서 time-slice를 다 씀
          sleep(1);
        }
      }
      else if(i == 3)
      {
      if(getpinfo(&st) < 0){
      printf(1, "getpinfo failed\n");
      exit();
    }
        // Process 4: no yield() (비치팅)
        for(ii = 0; ii < 50; ii++) 
        {
        for(k = 0; k < 1; k++) {

        workload(60000000); // 충분히 길게 일해서 time-slice를 다 씀
        }
        }
      }
    
      exit();
    }
  }

  int found = 0;
    sleep(1); // 1 ticks마다 스냅샷
    if(getpinfo(&st) < 0){
      printf(1, "getpinfo failed\n");
      exit();
    }
    printf(1, "PID\tInUse\tPriority\tState\tTicks(Q3 Q2 Q1 Q0)\tWait(Q3 Q2 Q1 Q0)\n");
    for(i = 0; i < NPROC; i++) {
      if(st.inuse[i]==0 && (st.pid[i]==pid[0]||st.pid[i]==pid[1]||st.pid[i]==pid[2]||st.pid[i]==pid[3])) {
        printf(1, "%d\t%d\t%d\t\t%d\t%d %d %d %d\t\t\t%d %d %d %d\n",
          st.pid[i], st.inuse[i], st.priority[i], st.state[i],
          st.ticks[i][3], st.ticks[i][2], st.ticks[i][1], st.ticks[i][0],
          st.wait_ticks[i][3], st.wait_ticks[i][2], st.wait_ticks[i][1], st.wait_ticks[i][0]);
          found = 1;
      }
    }
    if(!found)
      printf(1, "PID %d: not found or already exited\n", pid[i]);
  

  
  // 자식 종료 대기
  for(i = 0; i < NCHILD; i++)
    wait();

  printf(1, "=== Test Finished ===\n");
  for(i = 0; i < NPROC; i++) {
      if(st.inuse[i]==0 && (st.pid[i]==pid[0]||st.pid[i]==pid[1]||st.pid[i]==pid[2]||st.pid[i]==pid[3])) {
        printf(1, "%d\t%d\t%d\t\t%d\t%d %d %d %d\t\t\t%d %d %d %d\n",
          st.pid[i], st.inuse[i], st.priority[i], st.state[i],
          st.ticks[i][3], st.ticks[i][2], st.ticks[i][1], st.ticks[i][0],
          st.wait_ticks[i][3], st.wait_ticks[i][2], st.wait_ticks[i][1], st.wait_ticks[i][0]);
      }
    }
  exit();
}

