#include "types.h"
#include "stat.h"
#include "user.h"
#include "pstat.h"

#define NCHILD 3

// CPU를 소모하는 workload 함수
void workload(int n) {
  int i, j = 0;
  for(i = 0; i < n; i++)
    j += i * j + 1;
}

int main(void) {
  struct pstat st;
  int pid[NCHILD];
  int i;
  printf(1,"start mlfqtest\n");
  // MLFQ로 스케줄링 정책 변경 (정책 번호는 시스템에 따라 다를 수 있음)
  if(setSchedPolicy(1) != 0) {
    printf(1, "setSchedPolicy failed\n");
    exit();
  }
  // 자식 프로세스 생성
  for(i = 0; i < NCHILD; i++) {
    pid[i] = fork();
    printf(1, "makeprocess %d %d\n",pid[i], NCHILD);
    if(pid[i] == 0) {
      // 각 프로세스마다 workload 강도 다르게
      if(i == 0) {
        // Q3에서 Q2로 강등 테스트 (time-slice 소진)
        workload(4000000);
      } else if(i == 1) {
        // Q3->Q2->Q1까지 강등 테스트
        workload(8000000);
      } else {
        // Q3->Q2->Q1->Q0까지 강등 테스트
        workload(16000000);
      }
      exit();
    }
  }
  
  // 프로세스 정보 수집
  if(getpinfo(&st) < 0){
    printf(1, "getpinfo failed\n");
    exit();
  }
  
  // 모든 자식 종료 대기
  for(i = 0; i < NCHILD; i++){
    wait();
}
  // 결과 출력
  printf(1, "PID\tInUse\tPriority\tState\tTicks(Q3 Q2 Q1 Q0)\tWait(Q3 Q2 Q1 Q0)\n");
  for(i = 0; i < NPROC; i++) {
    if(st.inuse[i]) {
      printf(1, "%d\t%d\t%d\t\t%d\t%d %d %d %d\t%d %d %d %d\n",
        st.pid[i], st.inuse[i], st.priority[i], st.state[i],
        st.ticks[i][3], st.ticks[i][2], st.ticks[i][1], st.ticks[i][0],
        st.wait_ticks[i][3], st.wait_ticks[i][2], st.wait_ticks[i][1], st.wait_ticks[i][0]);
    }
  }

  exit();
}

