#include "types.h"
#include "stat.h"
#include "user.h"

/* Possible states of a thread; */
#define FREE 0x0
#define RUNNING 0x1
#define RUNNABLE 0x2
#define WAIT 0x3

#define STACK_SIZE 8192
#define MAX_THREAD 10

typedef struct thread thread_t, *thread_p;
typedef struct mutex mutex_t, *mutex_p;

struct thread {
int tid; /* thread id */
int sp; /* saved stack pointer */
char stack[STACK_SIZE]; /* the thread's stack */
int state; /* FREE, RUNNING, RUNNABLE, WAIT */
};
static thread_t all_thread[MAX_THREAD];
thread_p current_thread;
thread_p next_thread;
extern void thread_switch(void);
void thread_schedule(void);

void thread_schedule(void)
{
thread_p t;

printf(1, "DEBUG: Thread scheduler called\n");
printf(1, "DEBUG: Current thread: %d, state: %d\n",
current_thread ? current_thread->tid : -1,
current_thread ? current_thread->state : -1);

/* Find another runnable thread. */
next_thread = 0;
for (t = all_thread; t < all_thread + MAX_THREAD; t++) {
if (t->state == RUNNABLE && t != current_thread) {
next_thread = t;
printf(1, "DEBUG: Found runnable thread %d\n", t->tid);
break;
}
}

if (t >= all_thread + MAX_THREAD && current_thread->state == RUNNABLE) {
/* The current thread is the only runnable thread; run it. */
next_thread = current_thread;
printf(1, "DEBUG: Only current thread %d is runnable\n", current_thread->tid);
}

if (next_thread == 0) {
printf(2, "thread_schedule: no runnable threads\n");
exit();
}

if (current_thread != next_thread) { /* switch threads? */
printf(1, "DEBUG: Switching from thread %d to thread %d\n",
current_thread->tid, next_thread->tid);
next_thread->state = RUNNING;
current_thread->state = RUNNABLE;
thread_switch();
} else {
next_thread = 0;
}
}

void
thread_init(void)
{
// Initialize all threads as FREE
int i;
for(i = 0; i < MAX_THREAD; i++) {
all_thread[i].state = FREE;
all_thread[i].tid = 0;
}

// Initialize the first thread (main thread)
current_thread = &all_thread[0];
current_thread->state = RUNNING;
current_thread->tid = 0;

// Get the address of thread_schedule using a different approach
int scheduler_addr;
asm volatile("movl $thread_schedule, %0" : "=r" (scheduler_addr));

printf(1, "DEBUG: Scheduler address before init: %p\n", scheduler_addr);

// Initialize the thread system with scheduler function
uthread_init(scheduler_addr);

printf(1, "DEBUG: Thread system initialized\n");
printf(1, "DEBUG: Timer interrupt should now be active\n");
}

int
thread_create(void (*func)())
{
thread_p t;
static int next_tid = 1; // Start from 1 since 0 is main thread

for (t = all_thread; t < all_thread + MAX_THREAD; t++) {
if (t->state == FREE) break;
}

if (t >= all_thread + MAX_THREAD) {
printf(1, "thread_create: no free threads\n");
return -1;
}

// Set up the stack
t->sp = (int) (t->stack + STACK_SIZE); // set sp to the top of the stack

// Set up the initial context
t->sp -= 4; // space for return address
* (int *) (t->sp) = (int)func; // push return address on stack

t->sp -= 32; // space for registers that thread_switch expects
int *sp = (int*)t->sp;

// Initialize registers to 0
for(int i = 0; i < 8; i++) {
sp[i] = 0;
}

t->tid = next_tid++; // set unique tid and increment
t->state = RUNNABLE; // Mark as RUNNABLE immediately

printf(1, "DEBUG: Created thread %d with stack at %p and func at %p\n",
t->tid, t->stack, func);

return t->tid;
}

static void
thread_suspend(int tid)
{
thread_p t;

// Find the thread with matching tid
for (t = all_thread; t < all_thread + MAX_THREAD; t++) {
if (t->tid == tid && t->state == RUNNABLE) {
t->state = WAIT; // Change state from RUNNABLE to WAIT
break;
}
}
}

static void
thread_resume(int tid)
{
thread_p t;

// Find the thread with matching tid
for (t = all_thread; t < all_thread + MAX_THREAD; t++) {
if (t->tid == tid && t->state == WAIT) {
t->state = RUNNABLE; // Change state from WAIT to RUNNABLE
break;
}
}
}

static void
mythread(void)
{
int counter = 0;
printf(1, "DEBUG: Entering mythread for thread %d\n", current_thread->tid);

while(1) { // Run continuously until suspended
printf(1, "Thread %d is running at address: %p (counter: %d)\n",
current_thread->tid, mythread, counter++);
// No explicit yield - rely on timer interrupt for context switching
}

// This line will never be reached due to the infinite loop
current_thread->state = FREE;
}

int
main(int argc, char *argv[])
{
int tid1, tid2;
thread_init();

printf(1, "Creating threads...\n");
tid1 = thread_create(mythread);
tid2 = thread_create(mythread);
printf(1, "Created threads with IDs: %d and %d\n", tid1, tid2);

// Let both threads run for a while
printf(1, "Both threads should be running now...\n");
sleep(5); // Let both threads run and print for 5 seconds

printf(1, "Suspending thread %d\n", tid1);
thread_suspend(tid1);
printf(1, "Now only thread %d should be running...\n", tid2);
sleep(5); // Let only thread 2 run and print for 5 seconds

printf(1, "Suspending thread %d\n", tid2);
thread_suspend(tid2);
printf(1, "Now no threads should be running...\n");
sleep(2); // Wait with both threads suspended

printf(1, "Resuming thread %d\n", tid1);
thread_resume(tid1);
printf(1, "Now only thread %d should be running...\n", tid1);
sleep(5); // Let only thread 1 run and print for 5 seconds

printf(1, "Resuming thread %d\n", tid2);
thread_resume(tid2);
printf(1, "Now both threads should be running again...\n");
sleep(5); // Let both threads run and print for 5 seconds

// Exit the program
printf(1, "Test completed, exiting…\n");
exit();
}
