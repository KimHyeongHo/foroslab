//trap.c
#include "types.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"
#include "x86.h"
#include "traps.h"
#include "spinlock.h"
#include "i8254.h"
#include "pstat.h"


// Interrupt descriptor table (shared by all CPUs).
struct gatedesc idt[256];
extern uint vectors[];  // in vectors.S: array of 256 entry pointers
struct spinlock tickslock;
uint ticks;
extern int temp_ticks;
extern struct pstat pst;
extern int now_ticks[NPROC][4];
extern struct { struct spinlock lock; struct proc proc[NPROC]; } ptable;

void
tvinit(void)
{
  int i;

  for(i = 0; i < 256; i++)
    SETGATE(idt[i], 0, SEG_KCODE<<3, vectors[i], 0);
  SETGATE(idt[T_SYSCALL], 1, SEG_KCODE<<3, vectors[T_SYSCALL], DPL_USER);

  initlock(&tickslock, "time");
}

void
idtinit(void)
{
  lidt(idt, sizeof(idt));
}

//PAGEBREAK: 41
void
trap(struct trapframe *tf)
{
  int temp_policy;
  if(tf->trapno == T_SYSCALL){
    if(myproc()->killed)
      exit();
    myproc()->tf = tf;
    syscall();
    if(myproc()->killed)
      exit();
    return;
  }

  switch(tf->trapno){
  case T_IRQ0 + IRQ_TIMER:
    if(cpuid() == 0){
      acquire(&tickslock);
      temp_ticks++;
      ticks++;
      wakeup(&ticks);
      release(&tickslock);
    }
    //time_slice over
    if(myproc() && myproc()->state == RUNNING ) {
    int pr = myproc()->priority;
    int idx = myproc() - ptable.proc;
    temp_policy=mycpu()->sched_policy;
    if(temp_policy ==1 ||temp_policy ==2 ||temp_policy ==3) 
    {
    pst.ticks[idx][pr]++;
    }
    now_ticks[idx][pr]++;
    // now time-slice 초과 시 즉시 강등
   if(temp_policy ==1 ||temp_policy ==2 ||temp_policy ==3) {
      const int max_ticks[4] = {0, 32, 16, 8}; // Q3:8, Q2:16, Q1:32, Q0:0
      if ((now_ticks[idx][pr] >= max_ticks[pr]) &&
          (max_ticks[pr] >= 1)) {
          cprintf("Q time_slice down : %d pid %d Q%d→Q%d %d\n", now_ticks[idx][pr],myproc()->pid, pr, pr-1,mycpu()->sched_policy);
        pst.ticks[idx][pr] = 0;
        pst.wait_ticks[idx][pr] = 0;
        now_ticks[idx][pr] = 0;
        myproc()->priority--;
        yield();
    }
    if(pr==0 &&now_ticks[idx][0] >=100)
    {
        now_ticks[idx][pr] = 0;
        yield();
    }
    
  }
        // time-slice 초과 시 강등 및 ticks/wait_ticks 초기화
        const int max_ticks[4] = {0, 32, 16, 8};         // Q3:80, Q2:160, Q1:320, Q0:0
      if(mycpu()->sched_policy ==1 || mycpu()->sched_policy ==3){
      if (max_ticks[pr] != 0 &&
      pst.ticks[idx][pr] >= max_ticks[pr] &&
      max_ticks[pr] > 1) {
    cprintf("Q cheat time_slice down : %d pid %d Q%d→Q%d %d\n", now_ticks[idx][pr],myproc()->pid, pr, pr-1,mycpu()->sched_policy);
    pst.ticks[idx][pr] = 0;
    pst.wait_ticks[idx][pr] = 0;
    myproc()->priority--;
    yield();
  }
      }
  
  }
    lapiceoi();
    break;
  case T_IRQ0 + IRQ_IDE:
    ideintr();
    lapiceoi();
    break;
  case T_IRQ0 + IRQ_IDE+1:
    // Bochs generates spurious IDE1 interrupts.
    break;
  case T_IRQ0 + IRQ_KBD:
    kbdintr();
    lapiceoi();
    break;
  case T_IRQ0 + IRQ_COM1:
    uartintr();
    lapiceoi();
    break;
  case T_IRQ0 + 0xB:
    i8254_intr();
    lapiceoi();
    break;
  case T_IRQ0 + IRQ_SPURIOUS:
    cprintf("cpu%d: spurious interrupt at %x:%x\n",
            cpuid(), tf->cs, tf->eip);
    lapiceoi();
    break;

  //PAGEBREAK: 13
  default:
  /* in case for pagefault
    #define MAX_STACK_SIZE (8 * 1024 * 1024) // 8MB stack  
    
    uint addr = rcr2();
    
    if (KERNBASE - addr > MAX_STACK_SIZE) {
      cprintf("trap: stack limit exceeded at 0x%x\n", addr);
      myproc()->killed = 1;
      break;
      }
  */
    if(myproc() == 0 || (tf->cs&3) == 0){
      // In kernel, it must be our mistake.
      cprintf("unexpected trap %d from cpu %d eip %x (cr2=0x%x)\n",
              tf->trapno, cpuid(), tf->eip, rcr2());
      panic("trap");
    }
    // In user space, assume process misbehaved.
    cprintf("pid %d %s: trap %d err %d on cpu %d "
            "eip 0x%x addr 0x%x--kill proc\n",
            myproc()->pid, myproc()->name, tf->trapno,
            tf->err, cpuid(), tf->eip, rcr2());
    myproc()->killed = 1;
  }

  // Force process exit if it has been killed and is in user space.
  // (If it is still executing in the kernel, let it keep running
  // until it gets to the regular system call return.)
  if(myproc() && myproc()->killed && (tf->cs&3) == DPL_USER)
    exit();

  // Force process to give up CPU on clock tick.
  // If interrupts were on while locks held, would need to check nlock.
  //RR -> mlfq, ticks must give enough
  if(myproc() && myproc()->state == RUNNING &&
     tf->trapno == T_IRQ0+IRQ_TIMER)
     {
    //yield();
  }
  // Check if the process has been killed since we yielded
  if(myproc() && myproc()->killed && (tf->cs&3) == DPL_USER)
    exit();
}
