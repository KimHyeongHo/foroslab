#ifndef FONT_H_
#define FONT_H_

#define FONT_WIDTH 15
#define FONT_HEIGHT 30

void font_render(int x,int y,int index);
void font_render_string(char *string,int row);

#endif
