#include "types.h"
#include "stat.h"
#include "user.h"
#include "pstat.h"
#define NCHILD 4
void workload(int n) {
  int i, j = 0;
  for(i = 0; i < n; i++)
    j += i * j + 1;
}

int main(void) {
  struct pstat st;
  int pid[NCHILD];
  int i, k,snap;

  if(setSchedPolicy(3) != 0) {
    printf(1, "setSchedPolicy failed\n");
    exit();
  }

  for(i = 0; i < NCHILD; i++) {
    pid[i] = fork();
    if(pid[i] == 0) {
      if(i == 0 || i == 1) {
        // Process 1 & 2: yield() before 8 ticks (치팅)
        for(k = 0; k < 300; k++) {
          workload(4000000); // 짧게 일하고
          sleep(1);
        }
      } else {
        // Process 3 & 4: no yield() (time-slice를 다 씀)
        for(k = 0; k < 200; k++) {
          workload(32000000); // 충분히 길게 일해서 time-slice를 다 씀
          if(k%5==0)
          {
              sleep(1);
          }
        }
      }
      exit();
    }
  }

  // 충분히 기다린 뒤 getpinfo로 상태 확인
  // 여러 번 getpinfo로 상태 변화 추적
  for(snap=0; snap<80; snap++) {
  int found = 0;
    sleep(5); // 50 ticks마다 스냅샷
    if(getpinfo(&st) < 0){
      printf(1, "getpinfo failed\n");
      exit();
    }
    printf(1, "\n[Snapshot %d]\n", snap);
    printf(1, "PID\tInUse\tPriority\tState\tTicks(Q3 Q2 Q1 Q0)\tWait(Q3 Q2 Q1 Q0)\n");
    for(i = 0; i < NPROC; i++) {
      if(st.inuse[i]==0 && (st.pid[i]==pid[0]||st.pid[i]==pid[1]||st.pid[i]==pid[2]||st.pid[i]==pid[3])) {
        printf(1, "%d\t%d\t%d\t\t%d\t%d %d %d %d\t\t\t%d %d %d %d\n",
          st.pid[i], st.inuse[i], st.priority[i], st.state[i],
          st.ticks[i][3], st.ticks[i][2], st.ticks[i][1], st.ticks[i][0],
          st.wait_ticks[i][3], st.wait_ticks[i][2], st.wait_ticks[i][1], st.wait_ticks[i][0]);
          found = 1;
      }
    }
    if(!found)
      printf(1, "PID %d: not found or already exited\n", pid[i]);
  }

  
  // 자식 종료 대기
  for(i = 0; i < NCHILD; i++)
    wait();

  printf(1, "=== Test Finished ===\n");
  for(i = 0; i < NPROC; i++) {
      if(st.inuse[i]==0 && (st.pid[i]==pid[0]||st.pid[i]==pid[1]||st.pid[i]==pid[2]||st.pid[i]==pid[3])) {
        printf(1, "%d\t%d\t%d\t\t%d\t%d %d %d %d\t\t\t%d %d %d %d\n",
          st.pid[i], st.inuse[i], st.priority[i], st.state[i],
          st.ticks[i][3], st.ticks[i][2], st.ticks[i][1], st.ticks[i][0],
          st.wait_ticks[i][3], st.wait_ticks[i][2], st.wait_ticks[i][1], st.wait_ticks[i][0]);
      }
    }
  exit();
}

